alter table __schema__.convert_rule_item
	add skip boolean default false not null;
